# SmartCell — Loja virtual de smartphones

Projeto acadêmico de e-commerce desenvolvido para a atividade final do 4º bimestre do SENAC. A aplicação simula o fluxo de compra; não processa pagamentos reais.

## Tecnologias
- HTML5, CSS3, Bootstrap 5 e JavaScript
- PHP 8+ com Apache/XAMPP
- MySQL/MariaDB usando PDO e prepared statements
- Sessões PHP, `password_hash()` e `password_verify()`

## Instalação no XAMPP
1. Copie a pasta `SmartCell` para `C:\xampp\htdocs\`.
2. Inicie Apache e MySQL no XAMPP.
3. Acesse `http://localhost/phpmyadmin` e importe `database/schema.sql`. O script cria o banco `smartcell`, as tabelas e produtos demonstrativos.
4. Copie `.env.example` para `.env` e ajuste as credenciais do MySQL, se necessário.
5. Acesse `http://localhost/smartcell`.
6. Crie uma conta pela opção **Entrar > Cadastre-se**.

## Criar usuário administrador
Depois de cadastrar a conta, execute no phpMyAdmin (aba SQL), substituindo o e-mail pelo e-mail utilizado no cadastro:

```sql
USE smartcell;
UPDATE users SET role = 'admin' WHERE email = 'seu-email@exemplo.com';
```

Saia e entre novamente para atualizar a sessão. O acesso administrativo é validado no servidor.

## Funcionalidades
- Catálogo de smartphones e acessórios carregado do MySQL.
- Busca por texto e filtro por categoria.
- Página de detalhes com preço, descrição, imagem e estoque.
- Carrinho por `$_SESSION`, alteração de quantidade e remoção.
- Cadastro e login com senha criptografada.
- Checkout com simulação de PIX, boleto e cartão.
- Registro de pedidos e itens, baixa transacional do estoque e limpeza do carrinho.
- Painel administrativo com CRUD de produtos e consulta de pedidos.
- Proteção CSRF, controle de acesso, PDO e prepared statements.

## Entrega e Git
O `.env` com credenciais reais não deve ser enviado ao Git. O `.gitignore` já o ignora e o repositório deve manter apenas `.env.example`. Faça commits pequenos e frequentes durante o desenvolvimento.


### Imagens do catálogo
As imagens em `assets/images/products/` são ilustrações geradas para fins demonstrativos do projeto acadêmico. Elas ficam armazenadas localmente, então o catálogo não depende de links externos para exibi-las. Se importar o banco de dados novamente, os caminhos das imagens já estão configurados no `database/schema.sql`.
