<?php
require_once __DIR__ . '/includes/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ' . url('index.php')); exit; }
verify_csrf();
$id = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT) ?: 0;
$quantity = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT) ?: 1;
$stmt = $pdo->prepare('SELECT id, name, stock FROM products WHERE id = :id AND is_active = 1 LIMIT 1');
$stmt->execute(['id' => $id]); $product = $stmt->fetch();
if (!$product || (int)$product['stock'] < 1) { flash('danger', 'Este produto não está disponível.'); header('Location: ' . url('index.php')); exit; }
$quantity = max(1, min($quantity, (int)$product['stock']));
$current = (int)($_SESSION['cart'][$id] ?? 0);
$_SESSION['cart'][$id] = min($current + $quantity, (int)$product['stock']);
flash('success', 'Produto adicionado à sacola.');
header('Location: ' . url('cart.php')); exit;
