<?php
require __DIR__ . '/_guard.php';
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
$product = ['name'=>'','description'=>'','price'=>'','stock'=>'','image_url'=>'assets/images/product-default.svg','category_id'=>'','is_active'=>1];
if ($id) { $stmt = $pdo->prepare('SELECT * FROM products WHERE id = :id'); $stmt->execute(['id'=>$id]); $found = $stmt->fetch(); if (!$found) { http_response_code(404); exit('Produto não encontrado.'); } $product = $found; }
$categories = $pdo->query('SELECT id, name FROM categories ORDER BY name')->fetchAll(); $errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf(); $name = trim((string)($_POST['name'] ?? '')); $description = trim((string)($_POST['description'] ?? '')); $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT); $stock = filter_input(INPUT_POST, 'stock', FILTER_VALIDATE_INT); $category = filter_input(INPUT_POST, 'category_id', FILTER_VALIDATE_INT); $image = trim((string)($_POST['image_url'] ?? ''));
    if ($name === '') $errors[] = 'Informe o nome do produto.';
    if ($price === false || $price === null || $price < 0) $errors[] = 'Informe um preço válido.';
    if ($stock === false || $stock === null || $stock < 0) $errors[] = 'Informe um estoque válido.';
    if (!$category) $errors[] = 'Selecione uma categoria.';
    if ($image !== '' && !preg_match('~^(https?://|assets/)~i', $image)) $errors[] = 'A imagem deve ser uma URL http(s) ou um caminho dentro de assets/.';
    if (!$errors) {
        $data = ['name'=>$name, 'description'=>$description, 'price'=>$price, 'stock'=>$stock, 'image_url'=>$image ?: 'assets/images/product-default.svg', 'category_id'=>$category];
        if ($id) { $data['id']=$id; $stmt=$pdo->prepare('UPDATE products SET name=:name, description=:description, price=:price, stock=:stock, image_url=:image_url, category_id=:category_id WHERE id=:id'); $stmt->execute($data); flash('success','Produto atualizado.'); }
        else { $stmt=$pdo->prepare('INSERT INTO products (name, description, price, stock, image_url, category_id, is_active) VALUES (:name,:description,:price,:stock,:image_url,:category_id,1)'); $stmt->execute($data); flash('success','Produto cadastrado.'); }
        header('Location: ' . url('admin/products.php')); exit;
    }
    $product = array_merge($product, ['name'=>$name,'description'=>$description,'price'=>$price,'stock'=>$stock,'image_url'=>$image,'category_id'=>$category]);
}
$pageTitle = $id ? 'Editar produto' : 'Novo produto'; require dirname(__DIR__) . '/includes/header.php';
?>
<section class="container section-pad admin-page form-page"><a class="back-link" href="<?= e(url('admin/products.php')) ?>">← VOLTAR AOS PRODUTOS</a><div class="section-heading mt-4"><div><span class="eyebrow">CATÁLOGO / <?= $id ? 'EDIÇÃO' : 'NOVO ITEM' ?></span><h1><?= $id ? 'Editar' : 'Cadastrar' ?> <em>produto.</em></h1></div></div><div class="admin-form-card"><?php if ($errors): ?><div class="alert alert-danger"><?php foreach ($errors as $error): ?><div><?= e($error) ?></div><?php endforeach; ?></div><?php endif; ?><form method="post"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><div class="row g-3"><div class="col-md-8"><label>Nome do produto</label><input class="form-control" name="name" required value="<?= e($product['name']) ?>"></div><div class="col-md-4"><label>Categoria</label><select class="form-select" name="category_id" required><option value="">Selecione</option><?php foreach ($categories as $category): ?><option value="<?= (int)$category['id'] ?>" <?= (int)$product['category_id'] === (int)$category['id'] ? 'selected' : '' ?>><?= e($category['name']) ?></option><?php endforeach; ?></select></div><div class="col-md-4"><label>Preço (R$)</label><input class="form-control" type="number" name="price" min="0" step="0.01" required value="<?= e($product['price']) ?>"></div><div class="col-md-4"><label>Estoque</label><input class="form-control" type="number" name="stock" min="0" step="1" required value="<?= e($product['stock']) ?>"></div><div class="col-md-4"><label>Caminho/URL da imagem</label><input class="form-control" name="image_url" value="<?= e($product['image_url']) ?>" placeholder="assets/images/produto.svg"></div><div class="col-12"><label>Descrição</label><textarea class="form-control" name="description" rows="5"><?= e($product['description']) ?></textarea></div><div class="col-12 d-flex gap-2"><button class="btn-primary-aizen" type="submit">SALVAR PRODUTO ↗</button><a class="btn-outline-aizen" href="<?= e(url('admin/products.php')) ?>">CANCELAR</a></div></div></form></div></section>
<?php require dirname(__DIR__) . '/includes/footer.php'; ?>
