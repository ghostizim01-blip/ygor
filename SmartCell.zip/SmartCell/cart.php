<?php
require_once __DIR__ . '/includes/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    $id = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT) ?: 0;
    if ($action === 'remove') { unset($_SESSION['cart'][$id]); flash('success', 'Item removido da sacola.'); }
    if ($action === 'update') {
        $quantity = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT) ?: 1;
        $stmt = $pdo->prepare('SELECT stock, is_active FROM products WHERE id = :id'); $stmt->execute(['id' => $id]); $product = $stmt->fetch();
        if (!$product || !(int)$product['is_active'] || (int)$product['stock'] < 1) { unset($_SESSION['cart'][$id]); flash('warning', 'O produto não está mais disponível e foi removido.'); }
        else { $_SESSION['cart'][$id] = max(1, min($quantity, (int)$product['stock'])); flash('success', 'Quantidade atualizada.'); }
    }
    header('Location: ' . url('cart.php')); exit;
}
$items = cart_items($pdo); $total = array_sum(array_column($items, 'subtotal'));
$pageTitle = 'Sua sacola'; require __DIR__ . '/includes/header.php';
?>
<section class="container section-pad cart-page"><div class="section-heading"><div><span class="eyebrow">SEU PRÓXIMO MOVIMENTO</span><h1>Sua <em>sacola.</em></h1></div><span class="result-count"><?= cart_count() ?> ITEM(NS)</span></div>
<?php if (!$items): ?><div class="empty-state"><span>SC</span><h3>Sua sacola está vazia.</h3><p>Seu próximo smartphone está esperando por você.</p><a class="btn-primary-aizen" href="<?= e(url('index.php#catalogo')) ?>">EXPLORAR PRODUTOS ↗</a></div><?php else: ?>
<div class="row g-5"><div class="col-lg-8"><div class="cart-list">
<?php foreach ($items as $item): ?><div class="cart-item"><img src="<?= e(product_image($item['image_url'])) ?>" alt="<?= e($item['name']) ?>"><div class="cart-item-info"><h3><?= e($item['name']) ?></h3><span><?= money($item['price']) ?> / unidade</span><form method="post" class="quantity-form"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="update"><input type="hidden" name="product_id" value="<?= (int)$item['id'] ?>"><label>Qtd.</label><input type="number" name="quantity" min="1" max="<?= (int)$item['stock'] ?>" value="<?= (int)$item['quantity'] ?>"><button type="submit">ATUALIZAR</button></form></div><div class="cart-item-end"><strong><?= money($item['subtotal']) ?></strong><form method="post"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="remove"><input type="hidden" name="product_id" value="<?= (int)$item['id'] ?>"><button class="remove-link" type="submit">REMOVER ×</button></form></div></div><?php endforeach; ?>
</div></div><div class="col-lg-4"><aside class="summary-card"><span class="eyebrow">RESUMO DO PEDIDO</span><div class="summary-line"><span>Subtotal</span><strong><?= money($total) ?></strong></div><div class="summary-line"><span>Frete</span><strong>A calcular</strong></div><div class="summary-total"><span>Total</span><strong><?= money($total) ?></strong></div><p>O checkout é uma simulação acadêmica. Nenhuma cobrança real será feita.</p><a class="btn-primary-aizen w-100 text-center" href="<?= e(url('checkout.php')) ?>">CONTINUAR PARA CHECKOUT ↗</a><a class="continue-link" href="<?= e(url('index.php#catalogo')) ?>">Continuar comprando</a></aside></div></div><?php endif; ?></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
