<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();
$items = cart_items($pdo); $errors = [];
if (!$items) { flash('warning', 'Adicione produtos à sacola antes de finalizar.'); header('Location: ' . url('cart.php')); exit; }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf(); $payment = (string)($_POST['payment_method'] ?? '');
    if (!in_array($payment, ['PIX', 'Boleto', 'Cartão'], true)) $errors[] = 'Selecione uma forma de pagamento válida.';
    if (!$errors) {
        try {
            $pdo->beginTransaction(); $freshItems = []; $total = 0.0;
            foreach ($_SESSION['cart'] as $productId => $qty) {
                $stmt = $pdo->prepare('SELECT id, name, price, stock, is_active FROM products WHERE id = :id FOR UPDATE');
                $stmt->execute(['id'=>(int)$productId]); $product = $stmt->fetch();
                if (!$product || !(int)$product['is_active'] || (int)$product['stock'] < (int)$qty) throw new RuntimeException('Estoque insuficiente para um ou mais produtos. Revise sua sacola.');
                $product['quantity'] = (int)$qty; $product['price'] = (float)$product['price']; $total += $product['price'] * $product['quantity']; $freshItems[] = $product;
            }
            $orderStmt = $pdo->prepare('INSERT INTO orders (user_id, total, payment_method, status) VALUES (:user, :total, :payment, :status)');
            $orderStmt->execute(['user'=>current_user()['id'], 'total'=>$total, 'payment'=>$payment, 'status'=>'confirmado']); $orderId = (int)$pdo->lastInsertId();
            $itemStmt = $pdo->prepare('INSERT INTO order_items (order_id, product_id, product_name, quantity, unit_price) VALUES (:order_id, :product_id, :name, :quantity, :price)');
            $stockStmt = $pdo->prepare('UPDATE products SET stock = stock - :quantity WHERE id = :id AND stock >= :quantity_check');
            foreach ($freshItems as $item) {
                $itemStmt->execute(['order_id'=>$orderId, 'product_id'=>$item['id'], 'name'=>$item['name'], 'quantity'=>$item['quantity'], 'price'=>$item['price']]);
                $stockStmt->execute(['quantity'=>$item['quantity'], 'id'=>$item['id'], 'quantity_check'=>$item['quantity']]);
                if ($stockStmt->rowCount() !== 1) throw new RuntimeException('Não foi possível atualizar o estoque. Tente novamente.');
            }
            $pdo->commit(); $_SESSION['cart'] = []; header('Location: ' . url('order_success.php?id=' . $orderId)); exit;
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack(); $errors[] = $ex instanceof RuntimeException ? $ex->getMessage() : 'Não foi possível concluir o pedido. Tente novamente.';
            $items = cart_items($pdo);
        }
    }
}
$total = array_sum(array_map(fn($item) => (float)$item['price'] * (int)$item['quantity'], $items));
$pageTitle = 'Finalizar pedido'; require __DIR__ . '/includes/header.php';
?>
<section class="container section-pad checkout-page"><a class="back-link" href="<?= e(url('cart.php')) ?>">← VOLTAR À SACOLA</a><div class="section-heading mt-4"><div><span class="eyebrow">ÚLTIMA ETAPA</span><h1>Finalizar <em>pedido.</em></h1></div></div><div class="row g-5"><div class="col-lg-7"><div class="checkout-panel"><h2>Forma de pagamento</h2><p>Escolha uma opção para simular a confirmação da compra.</p><?php if ($errors): ?><div class="alert alert-danger"><?php foreach ($errors as $error): ?><div><?= e($error) ?></div><?php endforeach; ?></div><?php endif; ?><form method="post"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><div class="payment-options"><label class="payment-option"><input type="radio" name="payment_method" value="PIX" checked><span><b>PIX</b><small>Confirmação simulada imediata</small></span><strong>◈</strong></label><label class="payment-option"><input type="radio" name="payment_method" value="Boleto"><span><b>Boleto</b><small>Geração simulada de boleto</small></span><strong>▤</strong></label><label class="payment-option"><input type="radio" name="payment_method" value="Cartão"><span><b>Cartão</b><small>Transação fictícia, sem cobrança</small></span><strong>▣</strong></label></div><button class="btn-primary-aizen w-100 mt-4" type="submit">CONFIRMAR PEDIDO ↗</button></form><div class="simulation-note">⚠ Ambiente acadêmico: não informe dados bancários. O pagamento não é processado de verdade.</div></div></div><div class="col-lg-5"><aside class="summary-card"><span class="eyebrow">SEU PEDIDO</span><?php foreach ($items as $item): ?><div class="summary-line"><span><?= e($item['name']) ?> × <?= (int)$item['quantity'] ?></span><strong><?= money($item['price'] * $item['quantity']) ?></strong></div><?php endforeach; ?><div class="summary-total"><span>Total</span><strong><?= money($total) ?></strong></div><p>Ao confirmar, o estoque será atualizado automaticamente.</p></aside></div></div></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
