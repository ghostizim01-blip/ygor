CREATE DATABASE IF NOT EXISTS smartcell CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smartcell;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('customer','admin') NOT NULL DEFAULT 'customer',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE categories (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE products (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id INT UNSIGNED NOT NULL,
  name VARCHAR(160) NOT NULL,
  description TEXT NOT NULL,
  price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  stock INT UNSIGNED NOT NULL DEFAULT 0,
  image_url VARCHAR(500) DEFAULT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_products_category (category_id),
  INDEX idx_products_active (is_active),
  CONSTRAINT fk_products_category FOREIGN KEY (category_id) REFERENCES categories(id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE orders (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  payment_method ENUM('PIX','Boleto','Cartão') NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'confirmado',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_orders_user (user_id),
  CONSTRAINT fk_orders_user FOREIGN KEY (user_id) REFERENCES users(id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE order_items (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id INT UNSIGNED NOT NULL,
  product_id INT UNSIGNED DEFAULT NULL,
  product_name VARCHAR(160) NOT NULL,
  quantity INT UNSIGNED NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  INDEX idx_order_items_order (order_id),
  CONSTRAINT fk_order_items_order FOREIGN KEY (order_id) REFERENCES orders(id) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_order_items_product FOREIGN KEY (product_id) REFERENCES products(id) ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO categories (id, name) VALUES
(1, 'Apple'), (2, 'Samsung'), (3, 'Motorola'), (4, 'Xiaomi'), (5, 'Acessórios');

INSERT INTO products (category_id, name, description, price, stock, image_url) VALUES
(1, 'iPhone 15 128GB', 'Smartphone Apple iPhone 15 com tela Super Retina XDR de 6,1 polegadas, câmera principal de 48 MP e conexão 5G. Produto demonstrativo para o projeto acadêmico.', 4299.90, 12, 'assets/images/products/phone-1.jpg'),
(2, 'Samsung Galaxy S24 256GB', 'Smartphone Samsung Galaxy S24 com tela Dynamic AMOLED 2X, câmera avançada, desempenho para multitarefas e conectividade 5G. Produto demonstrativo.', 3899.00, 10, 'assets/images/products/phone-2.jpg'),
(3, 'Motorola Edge 50 Fusion 256GB', 'Smartphone Motorola Edge 50 Fusion com tela pOLED, câmera de alta resolução e carregamento rápido. Produto demonstrativo.', 2199.00, 15, 'assets/images/products/phone-3.jpg'),
(4, 'Xiaomi Redmi Note 13 256GB', 'Smartphone Xiaomi Redmi Note 13 com tela AMOLED, conjunto de câmeras versátil e bateria de longa duração. Produto demonstrativo.', 1499.90, 20, 'assets/images/products/phone-4.jpg'),
(2, 'Samsung Galaxy A55 128GB', 'Smartphone Samsung Galaxy A55 com tela Super AMOLED, câmera tripla e acabamento premium. Produto demonstrativo.', 1999.00, 8, 'assets/images/products/phone-5.jpg'),
(5, 'Carregador USB-C 25W', 'Carregador USB-C de 25W para smartphones compatíveis. Acessório demonstrativo para a loja acadêmica.', 89.90, 30, 'assets/images/products/phone-6.jpg');
