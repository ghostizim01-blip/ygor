</main>
<footer class="site-footer">
    <div class="container footer-inner">
        <div><a class="brand-mark footer-brand" href="<?= e(url('index.php')) ?>"><span class="brand-symbol">SC</span><span>SMARTCELL<small>SMARTPHONES</small></span></a><p>Tecnologia, qualidade e conectividade para todos os momentos.</p></div>
        <div class="footer-right"><span>SMARTCELL • SEU MUNDO CONECTADO.</span><small>Projeto acadêmico fictício • 4º bimestre</small></div>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(url('assets/js/app.js')) ?>"></script>
</body>
</html>
