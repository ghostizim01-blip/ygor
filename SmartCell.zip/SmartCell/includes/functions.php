<?php
declare(strict_types=1);

function e(mixed $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function url(string $path = ''): string {
    return APP_BASE_URL . '/' . ltrim($path, '/');
}

function product_image(?string $path): string {
    $path = trim((string)$path);
    if ($path !== '' && preg_match('~^https?://~i', $path)) return $path;
    return url($path !== '' ? $path : 'assets/images/product-default.svg');
}

function money(float|int|string $value): string {
    return 'R$ ' . number_format((float)$value, 2, ',', '.');
}

function csrf_token(): string {
    if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['_csrf'];
}

function verify_csrf(): void {
    $sent = $_POST['_csrf'] ?? '';
    if (!is_string($sent) || !hash_equals(csrf_token(), $sent)) {
        http_response_code(419);
        exit('Sua sessão expirou. Atualize a página e tente novamente.');
    }
}

function flash(string $type, string $message): void {
    $_SESSION['_flash'] = ['type' => $type, 'message' => $message];
}

function pull_flash(): ?array {
    $message = $_SESSION['_flash'] ?? null;
    unset($_SESSION['_flash']);
    return $message;
}

function current_user(): ?array {
    return $_SESSION['user'] ?? null;
}

function require_login(): void {
    if (!current_user()) {
        flash('warning', 'Entre na sua conta para continuar.');
        header('Location: ' . url('login.php'));
        exit;
    }
}

function require_admin(PDO $pdo): void {
    require_login();
    $stmt = $pdo->prepare('SELECT role FROM users WHERE id = :id LIMIT 1');
    $stmt->execute(['id' => current_user()['id']]);
    if ($stmt->fetchColumn() !== 'admin') {
        http_response_code(403);
        exit('Acesso permitido somente para administradores.');
    }
}

function cart_count(): int {
    return array_sum(array_map('intval', $_SESSION['cart'] ?? []));
}

function cart_items(PDO $pdo): array {
    $cart = $_SESSION['cart'] ?? [];
    if (!$cart) return [];
    $ids = array_values(array_filter(array_map('intval', array_keys($cart)), fn($id) => $id > 0));
    if (!$ids) return [];
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare("SELECT id, name, price, stock, image_url, is_active FROM products WHERE id IN ($placeholders)");
    $stmt->execute($ids);
    $products = $stmt->fetchAll();
    $items = [];
    foreach ($products as $product) {
        $id = (int)$product['id'];
        $qty = max(1, (int)($cart[$id] ?? 1));
        $qty = min($qty, max(0, (int)$product['stock']));
        if (!(int)$product['is_active'] || $qty < 1) continue;
        $product['quantity'] = $qty;
        $product['subtotal'] = $qty * (float)$product['price'];
        $items[] = $product;
    }
    return $items;
}
