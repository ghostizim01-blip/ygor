<?php
$pageTitle = $pageTitle ?? APP_NAME;
$activePage = $activePage ?? '';
$notice = pull_flash();
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#100d18">
    <title><?= e($pageTitle) ?> | <?= e(APP_NAME) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= e(url('assets/css/style.css')) ?>" rel="stylesheet">
</head>
<body>
<div class="announcement-bar">TECNOLOGIA QUE CONECTA VOCÊ AO FUTURO <span>✦</span> SMARTPHONES • ACESSÓRIOS • TECNOLOGIA</div>
<nav class="navbar navbar-expand-lg navbar-dark site-nav">
    <div class="container">
        <a class="navbar-brand brand-mark" href="<?= e(url('index.php')) ?>"><span class="brand-symbol">SC</span><span>SMARTCELL<small>SMARTPHONES</small></span></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-label="Abrir menu"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item"><a class="nav-link <?= $activePage === 'home' ? 'active' : '' ?>" href="<?= e(url('index.php')) ?>">Início</a></li>
                <li class="nav-item"><a class="nav-link <?= $activePage === 'catalog' ? 'active' : '' ?>" href="<?= e(url('index.php#catalogo')) ?>">Celulares</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= e(url('index.php#sobre')) ?>">Sobre</a></li>
                <?php if (current_user() && (current_user()['role'] ?? '') === 'admin'): ?><li class="nav-item"><a class="nav-link" href="<?= e(url('admin/index.php')) ?>">Admin</a></li><?php endif; ?>
            </ul>
            <div class="nav-actions">
                <a class="nav-text-link" href="<?= e(url('cart.php')) ?>">Sacola <span class="cart-count"><?= cart_count() ?></span></a>
                <?php if (current_user()): ?>
                    <span class="nav-user d-none d-lg-inline">Olá, <?= e(explode(' ', current_user()['name'])[0]) ?></span>
                    <form class="logout-form" method="post" action="<?= e(url('logout.php')) ?>"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><button class="nav-text-link" type="submit">Sair</button></form>
                <?php else: ?>
                    <a class="nav-login" href="<?= e(url('login.php')) ?>">Entrar</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>
<main>
<?php if ($notice): ?><div class="container pt-3"><div class="alert alert-<?= e($notice['type']) ?> alert-dismissible fade show" role="alert"><?= e($notice['message']) ?><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button></div></div><?php endif; ?>
