<?php
require_once __DIR__ . '/includes/bootstrap.php';
$search = trim((string)($_GET['q'] ?? ''));
$categoryId = filter_input(INPUT_GET, 'categoria', FILTER_VALIDATE_INT) ?: 0;
$categories = $pdo->query('SELECT id, name FROM categories ORDER BY name')->fetchAll();
$sql = 'SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON c.id = p.category_id WHERE p.is_active = 1';
$params = [];
if ($search !== '') { $sql .= ' AND (p.name LIKE :search_name OR p.description LIKE :search_description)'; $params['search_name'] = '%' . $search . '%'; $params['search_description'] = '%' . $search . '%'; }
if ($categoryId > 0) { $sql .= ' AND p.category_id = :category'; $params['category'] = $categoryId; }
$sql .= ' ORDER BY p.created_at DESC, p.id DESC';
$stmt = $pdo->prepare($sql); $stmt->execute($params); $products = $stmt->fetchAll();
$pageTitle = 'Encontre seu próximo smartphone'; $activePage = 'home';
require __DIR__ . '/includes/header.php';
?>
<section class="hero-section">
    <div class="hero-orbit orbit-one"></div><div class="hero-orbit orbit-two"></div>
    <div class="container hero-content">
        <div class="hero-copy">
            <span class="eyebrow"><i></i> SMARTPHONES • TECNOLOGIA • INOVAÇÃO</span>
            <h1>SEU PRÓXIMO<br>SMARTPHONE<br><em>ESTÁ AQUI.</em></h1>
            <p>Encontre smartphones de diferentes marcas e modelos, compare opções e escolha a tecnologia que combina com sua rotina.</p>
            <div class="hero-ctas"><a href="#catalogo" class="btn-primary-aizen">VER SMARTPHONES <span>↗</span></a><span class="hero-note">INOVAÇÃO • QUALIDADE • CONFIANÇA</span></div>
        </div>
        <div class="hero-art" aria-label="Arte abstrata em roxo e preto inspirada na estética SmartCell">
            <div class="hero-art-backdrop"></div><div class="hero-kanji">SC</div><div class="hero-ring ring-a"></div><div class="hero-ring ring-b"></div>
            <div class="hero-art-caption"><span>01 / 04</span><span>TECNOLOGIA AO SEU ALCANCE</span></div>
            <div class="hero-vertical">INOVAÇÃO EM CADA DETALHE</div>
        </div>
    </div>
    <div class="hero-bottom-line"><span>CONECTANDO VOCÊ AO QUE IMPORTA</span><span>SCROLL PARA DESCOBRIR ↓</span></div>
</section>
<section class="ticker-strip"><div class="ticker-track"><span>SMARTCELL ✦</span><span>TECNOLOGIA E CONFIANÇA ✦</span><span>SMARTCELL ✦</span><span>TECNOLOGIA E CONFIANÇA ✦</span></div></section>
<section class="catalog-section section-pad" id="catalogo">
    <div class="container">
        <div class="section-heading"><div><span class="eyebrow">DESTAQUES SMARTCELL</span><h2>Encontre o smartphone <em>ideal.</em></h2></div><span class="result-count"><?= count($products) ?> ITEM(NS) ENCONTRADO(S)</span></div>
        <form class="catalog-tools" method="get" action="<?= e(url('index.php')) ?>#catalogo">
            <div class="search-wrap"><span>⌕</span><input type="search" name="q" value="<?= e($search) ?>" placeholder="Buscar celulares..."></div>
            <select name="categoria" aria-label="Filtrar por categoria"><option value="0">Todas as categorias</option><?php foreach ($categories as $category): ?><option value="<?= (int)$category['id'] ?>" <?= $categoryId === (int)$category['id'] ? 'selected' : '' ?>><?= e($category['name']) ?></option><?php endforeach; ?></select>
            <button class="filter-button" type="submit">FILTRAR ↗</button>
        </form>
        <?php if (!$products): ?><div class="empty-state"><span>SC</span><h3>Nenhum produto encontrado.</h3><p>Tente outro termo ou limpe os filtros.</p><a href="<?= e(url('index.php#catalogo')) ?>">Ver todos os celulares</a></div><?php else: ?>
        <div class="row g-4 product-grid">
            <?php foreach ($products as $i => $product): ?>
            <div class="col-12 col-sm-6 col-lg-3">
                <article class="product-card">
                    <a class="product-image-link" href="<?= e(url('product.php?id=' . (int)$product['id'])) ?>">
                        <div class="product-image"><img src="<?= e(product_image($product['image_url'])) ?>" alt="<?= e($product['name']) ?>"><span class="product-index">0<?= $i + 1 ?></span><?php if ((int)$product['stock'] <= 0): ?><span class="sold-out">ESGOTADO</span><?php endif; ?></div>
                    </a>
                    <div class="product-meta"><span><?= e($product['category_name'] ?? 'Celulares') ?></span><span><?= (int)$product['stock'] > 0 ? 'EM ESTOQUE' : 'INDISPONÍVEL' ?></span></div>
                    <h3><a href="<?= e(url('product.php?id=' . (int)$product['id'])) ?>"><?= e($product['name']) ?></a></h3>
                    <div class="product-card-bottom"><strong><?= money($product['price']) ?></strong><a href="<?= e(url('product.php?id=' . (int)$product['id'])) ?>" aria-label="Ver <?= e($product['name']) ?>">↗</a></div>
                </article>
            </div>
            <?php endforeach; ?>
        </div><?php endif; ?>
    </div>
</section>
<section class="manifesto-section" id="sobre"><div class="container manifesto-inner"><span class="eyebrow">TECNOLOGIA PARA O SEU DIA A DIA</span><h2>“A tecnologia aproxima pessoas e transforma <em>possibilidades.</em>”</h2><div class="manifesto-bottom"><span>SMARTCELL STORE / SOBRE A LOJA 001</span><p>A SmartCell é uma loja virtual acadêmica dedicada à comercialização de smartphones e acessórios, com foco em praticidade, tecnologia e confiança.</p></div></div></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
