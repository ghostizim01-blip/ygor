<?php
require_once __DIR__ . '/includes/bootstrap.php';
if (current_user()) { header('Location: ' . url('index.php')); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf(); $email = strtolower(trim((string)($_POST['email'] ?? ''))); $password = (string)($_POST['password'] ?? '');
    $stmt = $pdo->prepare('SELECT id, name, email, password_hash, role FROM users WHERE email = :email LIMIT 1'); $stmt->execute(['email'=>$email]); $user = $stmt->fetch();
    if ($user && password_verify($password, $user['password_hash'])) {
        session_regenerate_id(true); unset($user['password_hash']); $_SESSION['user'] = $user; flash('success', 'Login realizado com sucesso.');
        header('Location: ' . url(($user['role'] === 'admin') ? 'admin/index.php' : 'index.php')); exit;
    }
    $error = 'E-mail ou senha incorretos.';
}
$pageTitle = 'Entrar'; require __DIR__ . '/includes/header.php';
?>
<section class="auth-section"><div class="auth-art"><span class="auth-kanji">SC</span><span class="auth-art-caption">YOUR REALITY. YOUR RULES.</span></div><div class="auth-panel"><span class="eyebrow">BEM-VINDO DE VOLTA À SMARTCELL</span><h1>Acesse sua <em>conta.</em></h1><p>Acesse sua conta para continuar comprando na SmartCell.</p><?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?><form method="post" class="auth-form"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><label>E-mail</label><input class="form-control" type="email" name="email" required value="<?= e($_POST['email'] ?? '') ?>"><label>Senha</label><input class="form-control" type="password" name="password" required><button class="btn-primary-aizen w-100" type="submit">ENTRAR ↗</button></form><p class="auth-switch">Ainda não tem conta? <a href="<?= e(url('register.php')) ?>">Cadastre-se</a></p></div></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
