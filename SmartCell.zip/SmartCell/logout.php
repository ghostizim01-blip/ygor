<?php
require_once __DIR__ . '/includes/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ' . url('index.php')); exit; }
verify_csrf();
unset($_SESSION['user']); session_regenerate_id(true); flash('success', 'Você saiu da sua conta.'); header('Location: ' . url('index.php')); exit;
