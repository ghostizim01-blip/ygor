<?php
require_once __DIR__ . '/includes/bootstrap.php'; require_login();
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
$stmt = $pdo->prepare('SELECT * FROM orders WHERE id = :id AND user_id = :user LIMIT 1'); $stmt->execute(['id'=>$id, 'user'=>current_user()['id']]); $order = $stmt->fetch();
if (!$order) { http_response_code(404); exit('Pedido não encontrado.'); }
$itemsStmt = $pdo->prepare('SELECT product_name, quantity, unit_price FROM order_items WHERE order_id = :id'); $itemsStmt->execute(['id'=>$id]); $items = $itemsStmt->fetchAll();
$pageTitle = 'Pedido confirmado'; require __DIR__ . '/includes/header.php';
?>
<section class="container section-pad success-page"><div class="success-symbol">✓</div><span class="eyebrow">COMPRA REALIZADA</span><h1>Pedido <em>confirmado.</em></h1><p>Obrigado por comprar na SmartCell. Esta é uma confirmação de pagamento simulada.</p><div class="order-receipt"><div class="summary-line"><span>Pedido</span><strong>#<?= (int)$order['id'] ?></strong></div><div class="summary-line"><span>Data</span><strong><?= e(date('d/m/Y H:i', strtotime($order['created_at']))) ?></strong></div><div class="summary-line"><span>Pagamento</span><strong><?= e($order['payment_method']) ?></strong></div><div class="summary-line"><span>Status</span><strong><?= e(ucfirst($order['status'])) ?></strong></div><hr><?php foreach ($items as $item): ?><div class="summary-line"><span><?= e($item['product_name']) ?> × <?= (int)$item['quantity'] ?></span><strong><?= money($item['unit_price'] * $item['quantity']) ?></strong></div><?php endforeach; ?><div class="summary-total"><span>Total</span><strong><?= money($order['total']) ?></strong></div></div><a class="btn-primary-aizen" href="<?= e(url('index.php')) ?>">VOLTAR À LOJA ↗</a></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
