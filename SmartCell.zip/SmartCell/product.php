<?php
require_once __DIR__ . '/includes/bootstrap.php';
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$stmt = $pdo->prepare('SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON c.id = p.category_id WHERE p.id = :id AND p.is_active = 1 LIMIT 1');
$stmt->execute(['id' => $id ?: 0]); $product = $stmt->fetch();
if (!$product) { http_response_code(404); $pageTitle = 'Produto não encontrado'; require __DIR__ . '/includes/header.php'; echo '<div class="container section-pad"><h1>Produto não encontrado.</h1><a href="' . e(url('index.php')) . '">Voltar à loja</a></div>'; require __DIR__ . '/includes/footer.php'; exit; }
$pageTitle = $product['name']; require __DIR__ . '/includes/header.php';
?>
<section class="container product-detail section-pad">
    <div class="detail-image"><img src="<?= e(product_image($product['image_url'])) ?>" alt="<?= e($product['name']) ?>"><span class="detail-stamp">SMARTCELL<br>COLLECTION</span></div>
    <div class="detail-copy"><a class="back-link" href="<?= e(url('index.php#catalogo')) ?>">← VOLTAR À CELULARES</a><span class="eyebrow mt-5"><?= e($product['category_name'] ?? 'CELULARES SMARTCELL') ?></span><h1><?= e($product['name']) ?></h1><div class="detail-price"><?= money($product['price']) ?></div><p class="detail-description"><?= nl2br(e($product['description'])) ?></p><div class="stock-line"><span class="stock-dot <?= (int)$product['stock'] > 0 ? 'available' : '' ?>"></span><?= (int)$product['stock'] > 0 ? 'Disponível • ' . (int)$product['stock'] . ' unidade(s)' : 'Produto indisponível no momento' ?></div>
        <?php if ((int)$product['stock'] > 0): ?><form method="post" action="<?= e(url('add_to_cart.php')) ?>" class="add-form"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="product_id" value="<?= (int)$product['id'] ?>"><label for="quantity">QUANTIDADE</label><input id="quantity" type="number" name="quantity" value="1" min="1" max="<?= (int)$product['stock'] ?>"><button type="submit" class="btn-primary-aizen">ADICIONAR À SACOLA ↗</button></form><?php endif; ?>
        <div class="detail-assurance"><span>✦</span> COMPRA SIMULADA <span>✦</span> ESTOQUE CONTROLADO</div>
    </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
