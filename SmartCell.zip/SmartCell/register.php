<?php
require_once __DIR__ . '/includes/bootstrap.php';
if (current_user()) { header('Location: ' . url('index.php')); exit; }
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf(); $name = trim((string)($_POST['name'] ?? '')); $email = strtolower(trim((string)($_POST['email'] ?? ''))); $password = (string)($_POST['password'] ?? '');
    if (mb_strlen($name) < 2) $errors[] = 'Informe seu nome completo.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Informe um e-mail válido.';
    if (strlen($password) < 8) $errors[] = 'A senha precisa ter pelo menos 8 caracteres.';
    if (!$errors) {
        try { $stmt = $pdo->prepare('INSERT INTO users (name, email, password_hash, role) VALUES (:name, :email, :hash, :role)'); $stmt->execute(['name'=>$name, 'email'=>$email, 'hash'=>password_hash($password, PASSWORD_DEFAULT), 'role'=>'customer']);
            session_regenerate_id(true); $_SESSION['user'] = ['id'=>(int)$pdo->lastInsertId(), 'name'=>$name, 'email'=>$email, 'role'=>'customer']; flash('success', 'Conta criada. Bem-vindo à SmartCell.'); header('Location: ' . url('index.php')); exit;
        } catch (PDOException $ex) { if ($ex->getCode() === '23000') $errors[] = 'Este e-mail já está cadastrado.'; else throw $ex; }
    }
}
$pageTitle = 'Criar conta'; require __DIR__ . '/includes/header.php';
?>
<section class="auth-section"><div class="auth-art"><span class="auth-kanji">SC</span><span class="auth-art-caption">THE NEW ORDER STARTS WITH YOU</span></div><div class="auth-panel"><span class="eyebrow">CRIE SUA CONTA SMARTCELL</span><h1>Crie sua <em>conta.</em></h1><p>Cadastre-se para comprar e acompanhar seus pedidos.</p><?php if ($errors): ?><div class="alert alert-danger"><?php foreach ($errors as $error): ?><div><?= e($error) ?></div><?php endforeach; ?></div><?php endif; ?><form method="post" class="auth-form"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><label>Nome completo</label><input class="form-control" name="name" required minlength="2" value="<?= e($_POST['name'] ?? '') ?>"><label>E-mail</label><input class="form-control" type="email" name="email" required value="<?= e($_POST['email'] ?? '') ?>"><label>Senha (mínimo 8 caracteres)</label><input class="form-control" type="password" name="password" required minlength="8"><button class="btn-primary-aizen w-100" type="submit">CRIAR CONTA ↗</button></form><p class="auth-switch">Já tem uma conta? <a href="<?= e(url('login.php')) ?>">Entrar</a></p></div></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
