# Portfólio Acadêmico — Ygor França de Souza (Turma 3TI02)

Portfólio web responsivo desenvolvido para a atividade final do 4º Bimestre (**SENAC Nações Unidas** — 3º ano do Ensino Médio Técnico em Tecnologia da Informação).

## Estrutura do Projeto
- `index.html`: Estrutura responsiva em HTML5 + Bootstrap 5.
- `style.css`: Estilo escuro tecnológico com detalhes em verde esmeralda e animações leves.
- `script.js`: Persistência em `LocalStorage` (JSON), 20 registros iniciais de teste, CRUD completo no painel administrativo, busca, filtro, marcação de lida/não lida e exportação JSON.
- `README.md`: Documentação técnica do projeto.
- `assets/img/`: Foto de perfil (`perfil-ygor.png`) e ilustrações dos projetos (`projeto-smartcell.png` e `projeto-controle-validade.png`).
