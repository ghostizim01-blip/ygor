const STORAGE_KEY = "portfolio_ygor_mensagens_v1";
const OWNER_EMAIL_KEY = "portfolio_ygor_owner_email";

const REGISTROS_TESTE_INICIAIS = [
  { id: 1, nome: "Ana Paula Ribeiro", email: "ana.ribeiro@canessolution.com.br", assunto: "Oportunidade / Estágio", telefone: "(11) 98111-1001", mensagem: "Olá Ygor, gostamos muito da organização do seu portfólio e dos projetos SmartCell e Controle de Validade.", data: "2026-11-10 09:15", lida: false },
  { id: 2, nome: "Prof. Carlos Mendes", email: "carlos.mendes@senacsp.edu.br", assunto: "Avaliação Acadêmica SENAC", telefone: "(11) 98111-1002", mensagem: "Parabéns pela entrega da estrutura responsiva e pela documentação clara das áreas do conhecimento.", data: "2026-11-10 10:30", lida: true },
  { id: 3, nome: "Lucas Ferreira", email: "lucas.dev@exemplo.com", assunto: "Dúvida sobre Projetos", telefone: "(11) 98111-1003", mensagem: "Como você estruturou o painel administrativo do projeto SmartCell em PHP?", data: "2026-11-11 14:20", lida: false },
  { id: 4, nome: "Mariana Costa", email: "mariana.costa@techrh.com", assunto: "Oportunidade / Estágio", telefone: "(11) 98111-1004", mensagem: "Temos vagas de estágio em desenvolvimento front-end para estudantes do 3º ano técnico.", data: "2026-11-11 16:45", lida: false },
  { id: 5, nome: "Rafael Oliveira", email: "rafael.oliveira@exemplo.com", assunto: "Dúvida sobre Projetos", telefone: "(11) 98111-1005", mensagem: "Achei bem interessante a lógica de comparação de datas no sistema Controle de Validade em Java Swing.", data: "2026-11-12 08:50", lida: true },
  { id: 6, nome: "Juliana Santos", email: "juliana.santos@canessolution.com.br", assunto: "Oportunidade / Estágio", telefone: "(11) 98111-1006", mensagem: "Estamos avaliando os portfólios da turma 3TI02 para o processo seletivo.", data: "2026-11-12 11:10", lida: false },
  { id: 7, nome: "Bruno Almeida", email: "bruno.almeida@exemplo.com", assunto: "Outro Assunto", telefone: "(11) 98111-1007", mensagem: "Gostei bastante da paleta escura com detalhes em verde, ficou bem legível no celular.", data: "2026-11-13 13:05", lida: true },
  { id: 8, nome: "Fernanda Lima", email: "fernanda.lima@senacsp.edu.br", assunto: "Avaliação Acadêmica SENAC", telefone: "(11) 98111-1008", mensagem: "Verificando os 20 registros iniciais no LocalStorage e a funcionalidade de exportação JSON.", data: "2026-11-13 15:40", lida: true },
  { id: 9, nome: "Gabriel Souza", email: "gabriel.souza@exemplo.com", assunto: "Dúvida sobre Projetos", telefone: "(11) 98111-1009", mensagem: "Você pretende continuar evoluindo o SmartCell com banco de dados MySQL?", data: "2026-11-14 09:00", lida: false },
  { id: 10, nome: "Camila Rocha", email: "camila.rocha@exemplo.com", assunto: "Oportunidade / Estágio", telefone: "(11) 98111-1010", mensagem: "Vi que você pretende cursar Engenharia de Software. Sucesso na graduação!", data: "2026-11-14 17:25", lida: false },
  { id: 11, nome: "Diego Martins", email: "diego.martins@exemplo.com", assunto: "Dúvida sobre Projetos", telefone: "(11) 98111-1011", mensagem: "Qual versão do NetBeans você utilizou na atividade de Controle de Validade?", data: "2026-11-15 10:12", lida: true },
  { id: 12, nome: "Patricia Gomes", email: "patricia.gomes@exemplo.com", assunto: "Outro Assunto", telefone: "(11) 98111-1012", mensagem: "Muito boa a conexão entre as atividades de Matemática e o raciocínio lógico.", data: "2026-11-15 14:55", lida: false },
  { id: 13, nome: "Rodrigo Teixeira", email: "rodrigo.t@exemplo.com", assunto: "Oportunidade / Estágio", telefone: "(11) 98111-1013", mensagem: "Gostaria de conversar sobre projetos web com HTML, CSS e JavaScript.", data: "2026-11-16 11:30", lida: false },
  { id: 14, nome: "Beatriz Nogueira", email: "beatriz.n@exemplo.com", assunto: "Avaliação Acadêmica SENAC", telefone: "(11) 98111-1014", mensagem: "Testando a busca e a edição de registros no painel administrativo.", data: "2026-11-16 16:00", lida: true },
  { id: 15, nome: "Thiago Barbosa", email: "thiago.b@exemplo.com", assunto: "Dúvida sobre Projetos", telefone: "(11) 98111-1015", mensagem: "A interface do catálogo de celulares ficou bem organizada.", data: "2026-11-17 09:40", lida: false },
  { id: 16, nome: "Larissa Pires", email: "larissa.pires@exemplo.com", assunto: "Outro Assunto", telefone: "(11) 98111-1016", mensagem: "Bacana o relato sobre o debate representando a China em Ciências Humanas.", data: "2026-11-17 15:18", lida: true },
  { id: 17, nome: "Gustavo Cardoso", email: "gustavo.c@exemplo.com", assunto: "Dúvida sobre Projetos", telefone: "(11) 98111-1017", mensagem: "Você disponibilizou o código da interface Swing no GitHub?", data: "2026-11-18 10:05", lida: false },
  { id: 18, nome: "Amanda Vieira", email: "amanda.vieira@exemplo.com", assunto: "Oportunidade / Estágio", telefone: "(11) 98111-1018", mensagem: "Perfil muito alinhado com vagas de suporte e desenvolvimento júnior.", data: "2026-11-18 18:10", lida: false },
  { id: 19, nome: "Felipe Duarte", email: "felipe.duarte@exemplo.com", assunto: "Outro Assunto", telefone: "(11) 98111-1019", mensagem: "Excelente resumo sobre Cibersegurança e Computação em Nuvem.", data: "2026-11-19 12:45", lida: true },
  { id: 20, nome: "Renata Azevedo", email: "renata.azevedo@canessolution.com.br", assunto: "Avaliação Acadêmica SENAC", telefone: "(11) 98111-1020", mensagem: "Validação final dos 20 registros de teste concluída com sucesso.", data: "2026-11-20 08:30", lida: false }
];

let modalCrudInstance = null;

document.addEventListener("DOMContentLoaded", () => {
  inicializarLocalStorage();
  inicializarEmailProprietario();
  inicializarAnimacoes();
  configurarEventos();
  renderizarTabelaMensagens();
});

function inicializarLocalStorage() {
  const dadosSalvos = localStorage.getItem(STORAGE_KEY);
  if (!dadosSalvos) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(REGISTROS_TESTE_INICIAIS));
  } else {
    try {
      const parsed = JSON.parse(dadosSalvos);
      if (!Array.isArray(parsed) || parsed.length === 0) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(REGISTROS_TESTE_INICIAIS));
      }
    } catch (e) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(REGISTROS_TESTE_INICIAIS));
    }
  }
}

function obterMensagens() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
  } catch (e) {
    return [];
  }
}

function salvarMensagens(lista) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(lista));
  renderizarTabelaMensagens();
}

function inicializarEmailProprietario() {
  const savedEmail = localStorage.getItem(OWNER_EMAIL_KEY);
  const input = document.getElementById("ownerEmailInput");
  if (savedEmail && input) {
    input.value = savedEmail;
  }
}

function inicializarAnimacoes() {
  const elements = document.querySelectorAll(".reveal");
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12 }
  );
  elements.forEach((el) => observer.observe(el));
}

function configurarEventos() {
  const painelAdmin = document.getElementById("painel-admin");
  const btnToggleAdmin = document.getElementById("btnToggleAdmin");
  const btnFecharAdmin = document.getElementById("btnFecharAdmin");

  btnToggleAdmin.addEventListener("click", () => {
    painelAdmin.classList.toggle("d-none");
    if (!painelAdmin.classList.contains("d-none")) {
      painelAdmin.scrollIntoView({ behavior: "smooth" });
    }
  });

  btnFecharAdmin.addEventListener("click", () => {
    painelAdmin.classList.add("d-none");
  });

  document.addEventListener("keydown", (e) => {
    if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "a") {
      e.preventDefault();
      painelAdmin.classList.toggle("d-none");
      if (!painelAdmin.classList.contains("d-none")) {
        painelAdmin.scrollIntoView({ behavior: "smooth" });
      }
    }
  });

  document.getElementById("btnSaveOwnerEmail").addEventListener("click", () => {
    const emailVal = document.getElementById("ownerEmailInput").value.trim();
    if (!emailVal || !emailVal.includes("@")) {
      alert("Por favor, insira um endereço de e-mail válido.");
      return;
    }
    localStorage.setItem(OWNER_EMAIL_KEY, emailVal);
    alert(`E-mail de destino atualizado para: ${emailVal}`);
  });

  const contactForm = document.getElementById("contactForm");
  contactForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const nome = document.getElementById("nome").value.trim();
    const email = document.getElementById("email").value.trim();
    const assunto = document.getElementById("assunto").value;
    const telefone = document.getElementById("telefone").value.trim() || "Não informado";
    const mensagem = document.getElementById("mensagem").value.trim();
    const abrirEmailCliente = document.getElementById("abrirEmailCliente").checked;

    if (!nome || !email || !mensagem) {
      exibirFeedback("Preencha os campos obrigatórios (Nome, E-mail e Mensagem).", "danger");
      return;
    }

    const lista = obterMensagens();
    const novoId = lista.length > 0 ? Math.max(...lista.map((m) => m.id)) + 1 : 1;
    const agora = new Date();
    const dataFormatada = agora.toLocaleDateString("pt-BR") + " " + agora.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });

    const novaMensagem = {
      id: novoId,
      nome,
      email,
      assunto,
      telefone,
      mensagem,
      data: dataFormatada,
      lida: false
    };

    lista.unshift(novaMensagem);
    salvarMensagens(lista);

    const destino = document.getElementById("ownerEmailInput").value.trim() || "ygor.fsouza@senacsp.edu.br";

    if (abrirEmailCliente) {
      const subjectEncoded = encodeURIComponent(`[Portfólio Ygor] ${assunto} - ${nome}`);
      const bodyEncoded = encodeURIComponent(
        `Olá Ygor,\n\nVocê recebeu uma nova mensagem pelo seu portfólio:\n\n` +
        `Nome: ${nome}\n` +
        `E-mail: ${email}\n` +
        `Telefone: ${telefone}\n` +
        `Assunto: ${assunto}\n\n` +
        `Mensagem:\n${mensagem}\n`
      );
      window.location.href = `mailto:${destino}?subject=${subjectEncoded}&body=${bodyEncoded}`;
      exibirFeedback(
        `Mensagem salva no LocalStorage e cliente de e-mail acionado para envio real para <strong>${destino}</strong>.`,
        "success"
      );
    } else {
      exibirFeedback(
        `Mensagem salva localmente no navegador (LocalStorage). Para envio real por e-mail, marque a opção de envio ou envie diretamente para <strong>${destino}</strong>.`,
        "info"
      );
    }

    contactForm.reset();
  });

  document.getElementById("buscaMensagens").addEventListener("input", renderizarTabelaMensagens);
  document.getElementById("filtroStatus").addEventListener("change", renderizarTabelaMensagens);

  document.getElementById("btnExportarJson").addEventListener("click", () => {
    const lista = obterMensagens();
    const blob = new Blob([JSON.stringify(lista, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "mensagens_portfolio_ygor.json";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  });

  document.getElementById("btnRestaurar20").addEventListener("click", () => {
    if (confirm("Deseja restaurar os 20 registros de teste padrão no LocalStorage?")) {
      salvarMensagens([...REGISTROS_TESTE_INICIAIS]);
    }
  });

  const modalEl = document.getElementById("modalEditarMensagem");
  modalCrudInstance = new bootstrap.Modal(modalEl);

  document.getElementById("btnNovoRegistroModal").addEventListener("click", () => {
    document.getElementById("modalEditarLabel").textContent = "Nova Mensagem (Admin Local)";
    document.getElementById("crudId").value = "";
    document.getElementById("crudNome").value = "";
    document.getElementById("crudEmail").value = "";
    document.getElementById("crudAssunto").value = "Registro Administrativo";
    document.getElementById("crudMensagem").value = "";
    document.getElementById("crudLida").checked = false;
    modalCrudInstance.show();
  });

  document.getElementById("formAdminCrud").addEventListener("submit", (e) => {
    e.preventDefault();
    const idVal = document.getElementById("crudId").value;
    const nome = document.getElementById("crudNome").value.trim();
    const email = document.getElementById("crudEmail").value.trim();
    const assunto = document.getElementById("crudAssunto").value.trim();
    const mensagem = document.getElementById("crudMensagem").value.trim();
    const lida = document.getElementById("crudLida").checked;

    const lista = obterMensagens();

    if (idVal) {
      const index = lista.findIndex((item) => item.id === Number(idVal));
      if (index !== -1) {
        lista[index] = { ...lista[index], nome, email, assunto, mensagem, lida };
      }
    } else {
      const novoId = lista.length > 0 ? Math.max(...lista.map((m) => m.id)) + 1 : 1;
      const agora = new Date();
      const dataFormatada = agora.toLocaleDateString("pt-BR") + " " + agora.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
      lista.unshift({
        id: novoId,
        nome,
        email,
        assunto,
        telefone: "Cadastro Manual",
        mensagem,
        data: dataFormatada,
        lida
      });
    }

    salvarMensagens(lista);
    modalCrudInstance.hide();
  });
}

function exibirFeedback(htmlMsg, tipo) {
  const box = document.getElementById("formFeedback");
  box.innerHTML = `<div class="alert alert-${tipo} py-2 px-3 small mb-0">${htmlMsg}</div>`;
}

function renderizarTabelaMensagens() {
  const lista = obterMensagens();
  const termo = document.getElementById("buscaMensagens").value.toLowerCase().trim();
  const filtro = document.getElementById("filtroStatus").value;

  const total = lista.length;
  const lidas = lista.filter((m) => m.lida).length;
  const naoLidas = total - lidas;

  document.getElementById("statTotal").textContent = total;
  document.getElementById("statNaoLidas").textContent = naoLidas;
  document.getElementById("statLidas").textContent = lidas;

  const filtradas = lista.filter((m) => {
    const matchTexto =
      m.nome.toLowerCase().includes(termo) ||
      m.email.toLowerCase().includes(termo) ||
      m.assunto.toLowerCase().includes(termo) ||
      m.mensagem.toLowerCase().includes(termo);

    const matchStatus =
      filtro === "todas" ||
      (filtro === "lida" && m.lida) ||
      (filtro === "nao_lida" && !m.lida);

    return matchTexto && matchStatus;
  });

  const tbody = document.getElementById("tabelaMensagensBody");
  if (filtradas.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" class="text-center text-muted py-4">Nenhuma mensagem encontrada para os filtros atuais.</td></tr>`;
    return;
  }

  tbody.innerHTML = filtradas
    .map(
      (msg) => `
      <tr class="${msg.lida ? "opacity-75" : ""}">
        <td>
          ${
            msg.lida
              ? '<span class="badge bg-secondary">Lida</span>'
              : '<span class="badge bg-accent-subtle text-accent">Não lida</span>'
          }
        </td>
        <td>
          <div class="fw-semibold text-white">${escapeHtml(msg.nome)}</div>
          <div class="small text-muted">${escapeHtml(msg.email)}</div>
        </td>
        <td><span class="small text-info">${escapeHtml(msg.assunto)}</span></td>
        <td><div class="small text-secondary-light" style="max-width: 280px;">${escapeHtml(msg.mensagem)}</div></td>
        <td><span class="small font-mono text-muted">${escapeHtml(msg.data)}</span></td>
        <td class="text-end text-nowrap">
          <button class="btn btn-sm btn-outline-info me-1" onclick="alternarLida(${msg.id})" title="${msg.lida ? "Marcar como não lida" : "Marcar como lida"}">
            <i class="bi ${msg.lida ? "bi-envelope" : "bi-envelope-open"}"></i>
          </button>
          <button class="btn btn-sm btn-outline-accent me-1" onclick="abrirModalEdicao(${msg.id})" title="Editar">
            <i class="bi bi-pencil"></i>
          </button>
          <button class="btn btn-sm btn-outline-danger" onclick="excluirMensagem(${msg.id})" title="Excluir">
            <i class="bi bi-trash"></i>
          </button>
        </td>
      </tr>
    `
    )
    .join("");
}

window.alternarLida = function (id) {
  const lista = obterMensagens();
  const idx = lista.findIndex((m) => m.id === id);
  if (idx !== -1) {
    lista[idx].lida = !lista[idx].lida;
    salvarMensagens(lista);
  }
};

window.abrirModalEdicao = function (id) {
  const lista = obterMensagens();
  const item = lista.find((m) => m.id === id);
  if (!item) return;

  document.getElementById("modalEditarLabel").textContent = `Editar Mensagem #${item.id}`;
  document.getElementById("crudId").value = item.id;
  document.getElementById("crudNome").value = item.nome;
  document.getElementById("crudEmail").value = item.email;
  document.getElementById("crudAssunto").value = item.assunto;
  document.getElementById("crudMensagem").value = item.mensagem;
  document.getElementById("crudLida").checked = item.lida;
  modalCrudInstance.show();
};

window.excluirMensagem = function (id) {
  if (!confirm("Deseja realmente excluir esta mensagem?")) return;
  const lista = obterMensagens().filter((m) => m.id !== id);
  salvarMensagens(lista);
};

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
